const fs = require('fs');
let { exist } = require('../var/variable');

const isDupe = (books, data) => {
    for (let book of books) {
        if (book.name === data.name && book.author === data.author) {
            return true;
        }
    }
};

const writeData = async (path, data, isAlter) => {
    let add;
    try {
        add = fs.createWriteStream(path);
    } catch (error) {
        console.log('error saat membaca file dan lokasi file');
    }
    if (isAlter) {
        exist = data;
    } else {
        exist.push(data);
    }
    try {
        add.write(JSON.stringify(exist));
    } catch (error) {
        console.log('error saat writing data');
    }
};

const readData = async (path) => {
    let t;
    try {
        t = JSON.parse(fs.readFileSync(path, { encoding: 'utf8', flag: 'r' }));
    } catch (error) {
        console.log('error read parse', t);
    }
    if (t.length > 0 && t.length > exist.length) {
        for (let ex in t) {
            exist.push(t[ex]);
        }
    } else if (t.length === 0 && t.length === undefined) {
        return [];
    }
};

module.exports = { writeData, readData, isDupe };

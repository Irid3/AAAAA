let { o, n, dataValid } = require('../var/variable');

const isPageRead = async (data) => {
    if (data.readPage > data.pageCount) return { msg: 'Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount', itIs: true };
    if (data.readPage < 0) return { msg: 'Gagal menambah buku. readPage tidak boleh lebih kecil dari 0', itIs: true };
    return { msg: '', itIs: false };
};

const isDataNull = async (data) => {
    n.length = 0;
    let message = {};
    let nullIs = false;
    await Object.entries(dataValid).forEach(([key]) => {
        if (data[key] == (undefined || null)) {
            n.push(`Gagal menambahkan buku. Mohon isi ${key === 'name' ? 'nama' : key} buku`);
            nullIs = true;
        }
    });
    if (nullIs) {
        if (data.name == undefined) {
            n.forEach((data) => (message = data));
            return { msg: message, isNull: nullIs };
        }
        n.forEach((data, index) => (message[`message${index + 1}`] = data));
        return { msg: message, isNull: nullIs };
    }
    return { msg: message, isNull: nullIs };
};

const isValid = (data) => {
    if (typeof data.name !== typeof dataValid.name && data.name != (undefined || null)) o.push(['name', 'string']);
    if (typeof data.year !== typeof dataValid.year) o.push(['year', 'number']);
    if (typeof data.author !== typeof dataValid.author) o.push(['author', 'string']);
    if (typeof data.summary !== typeof dataValid.summary) o.push(['summary', 'string']);
    if (typeof data.publisher !== typeof dataValid.publisher) o.push(['publisher', 'string']);
    if (typeof data.pageCount !== typeof dataValid.pageCount) o.push(['pageCount', 'number']);
    if (typeof data.readPage !== typeof dataValid.readPage) o.push(['readPage', 'number']);
    if (typeof data.reading !== typeof dataValid.reading) o.push(['reading', 'boolean']);

    let message = {};

    for (let i = 0; i < o.length; i++) {
        message[`message${i + 1}`] = `Gagal menambahkan buku silahkan isi ${o[i][0]} dengan format ${o[i][1]}`;
    }
    if (o.length > 0) return { msg: message, valid: false };
    return { valid: true };
};

module.exports = { isValid, isDataNull, isPageRead };

const { path: stored, exist, dataValid } = require('./var/variable');
const { readData, writeData } = require('./func/fileCheck');

const PutBookById = async (req, h) => {
    let { bookid: id } = req.params;
    let dataI = req.payload;
    await readData(stored);
    const cekParam = (data) => {
        let temp = {};
        let isItNull = false;
        Object.entries(dataValid).forEach(([key], index) => {
            try {
                if (data[key] === (null || undefined)) {
                    if (key === 'name') {
                        temp = `Gagal memperbarui buku. Mohon isi ${key == 'name' ? 'nama' : key} buku`;
                        isItNull = true;
                    } else {
                        temp[`message${index + 1}`] = `Gagal memperbarui buku. Mohon isi ${key == 'name' ? 'nama' : key} buku`;
                        isItNull = true;
                    }
                } else if (key === 'pageCount') {
                    if (data.readPage > data[key]) {
                        temp = 'Gagal memperbarui buku. readPage tidak boleh lebih besar dari pageCount';
                        isItNull = true;
                    }
                }
            } catch (error) {
                console.log('check null error');
            }
        });
        return { msgNull: temp, isItNull };
    };

    let { msgNull: msgN, isItNull } = cekParam(dataI);
    let temp = {};
    exist.map((data) => {
        if (data.id === id) {
            Object.entries(dataI).forEach(([key]) => {
                data[key] = dataI[key];
            });
            data['updatedAt'] = new Date().toISOString();
            temp = data;
        }
    });
    try {
        await writeData('handler/data/books.txt', exist, true);
    } catch (error) {
        console.log('Kesalahan saat write data');
    }
    if (isItNull) {
        const res = h.response({
            status: 'fail',
            message: msgN
        });
        res.code(400);
        return res;
    } else if (temp.name === dataI.name) {
        const res = h.response({
            status: 'success',
            message: 'Buku berhasil diperbarui'
        });
        res.code(200);
        return res;
    } else {
        const res = h.response({
            status: 'fail',
            message: 'Gagal memperbarui buku. Id tidak ditemukan'
        });
        res.code(404);
        return res;
    }
};

const DeleteBookById = async (req, h) => {
    let { bookid: id } = req.params;
    await readData(stored);
    let deleted = false;
    try {
        exist.map((data, index) => {
            if (data.id == id) {
                exist.splice(index, 1);
                deleted = true;
            }
        });
    } catch {
        console.log('gagal menghapus data');
    }
    if (deleted) {
        const res = h.response({
            status: 'success',
            message: 'Buku berhasil dihapus'
        });
        try {
            await writeData(stored, exist, true);
        } catch (error) {
            console.log('gagal write data');
        }
        res.code(200);
        return res;
    } else {
        const res = h.response({
            status: 'fail',
            message: 'Buku gagal dihapus. Id tidak ditemukan'
        });
        res.code(404);
        return res;
    }
};

module.exports = { PutBookById, DeleteBookById };

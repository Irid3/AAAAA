const { nanoid } = require('nanoid');
const { isValid, isDataNull, isPageRead } = require('./func/isValid');
const { writeData } = require('./func/fileCheck'); // , isDupe
// let { exist } = require('./var/variable');

const PostBook = async (data, h) => {
    let { msg, valid } = await isValid(data.payload);
    let { msg: nmsg, isNull } = await isDataNull(data.payload);
    let { msg: rmsg, itIs } = await isPageRead(data.payload);
    const id = nanoid(32);
    let isFinished = data.payload.pageCount == data.payload.readPage ? true : false;
    const createdAt = new Date().toISOString();
    const updatedAt = createdAt;

    let books = {
        id: id,
        name: data.payload.name,
        year: data.payload.year,
        author: data.payload.author,
        summary: data.payload.summary,
        publisher: data.payload.publisher,
        pageCount: data.payload.pageCount,
        readPage: data.payload.readPage,
        finished: isFinished,
        reading: data.payload.reading,
        insertedAt: createdAt,
        updatedAt: updatedAt
    };

    const isSuccess = books.id.length > 0;
    if (isNull) {
        const response = h.response({
            status: 'fail',
            message: nmsg
        });
        response.code(400);
        return response;
    } else if (itIs) {
        const response = h.response({
            status: 'fail',
            message: rmsg
        });
        response.code(400);
        return response;
    } else if (isSuccess && valid) {
        try {
            await writeData('handler/data/books.txt', books, false);
        } catch (error) {
            console.log('kesalahan saat write data', error);
        }
        const response = h.response({
            status: 'success',
            message: 'Buku berhasil ditambahkan',
            data: {
                bookId: id
            }
        });
        response.code(201);
        return response;
    }
    // else if (isDupe(exist, books)) {!isDupe(exist, books) //check if duplicates
    //     const response = h.response({
    //         status: 'fail',
    //         message: 'nama dan auhtor sudah ada didalam database'
    //     });
    //     response.code(400);
    //     return response;
    // }
    const response = h.response({
        status: 'fail',
        message: msg
    });
    response.code(400);
    return response;
};

module.exports = PostBook;

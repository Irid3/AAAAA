let o = [];
let n = [];
let dataValid = {
    name: '',
    year: 1,
    author: '',
    summary: '',
    publisher: '',
    pageCount: 1,
    readPage: 1,
    reading: false
};
let exist = [];
let path = 'handler/data/books.txt';

module.exports = { o, n, dataValid, exist, path };

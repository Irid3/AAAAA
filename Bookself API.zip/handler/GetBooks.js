const { path: stored, exist } = require('./var/variable');
const { readData } = require('./func/fileCheck');
let porpsByname = ['id', 'name', 'publisher'];

const GetBook = async (req, h) => {
    let name = req.query.name;
    let reading = req.query.reading;
    let finished = req.query.finished;
    if (name !== (null || undefined)) {
        return await GetBookByName(name, h);
    } else if (reading !== (null || undefined)) {
        return await GetBookByReading(reading, h);
    } else if (finished !== (null || undefined)) {
        return await GetBookByFinished(finished, h);
    } else {
        await readData(stored);
        if (exist) {
            let temp = [];
            for (let books in exist) {
                temp.push({ id: exist[books].id, name: exist[books].name, publisher: exist[books].publisher });
            }
            const res = h.response({
                status: 'success',
                data: { books: temp }
            });
            res.code(200);
            return res;
        } else {
            const res = h.response({
                status: 'fail',
                data: { books: exist }
            });
            res.code(400);
            return res;
        }
    }
};
const GetBookById = async (req, h) => {
    const { bookid } = req.params;
    await readData(stored);
    for (let book in exist) {
        if (exist[book].id === bookid) {
            const res = h.response({
                status: 'success',
                data: { book: exist[book] }
            });
            res.code(200);
            return res;
        }
    }
    const res = h.response({
        status: 'fail',
        message: 'Buku tidak ditemukan'
    });
    res.code(404);
    return res;
};

const GetBookByName = async (req, h) => {
    let name = req;
    let reg = new RegExp(name, 'i');
    let temp = [];
    let tempO = {};
    if (name == undefined) {
        const res = h.response({
            status: 'fail',
            message: 'Buku tidak ditemukan'
        });
        res.code(404);
        return res;
    }
    await readData(stored);
    exist.forEach((data) => {
        if (reg.test(data.name)) {
            Object.entries(data).forEach(([key]) => {
                porpsByname.forEach((datas) => {
                    if (key == datas) {
                        tempO[key] = data[key];
                    }
                });
            });
            temp.push(tempO);
        }
    });
    if (temp.length > 0) {
        const res = h.response({
            status: 'success',
            data: { books: temp }
        });
        res.code(200);
        return res;
    }
};
const GetBookByReading = async (req, h) => {
    let reading = req;
    let temp = [];
    let tempO = {};
    let isR = reading == 0 ? false : true;
    await readData(stored);

    exist.forEach((data) => {
        if (data.reading === isR) {
            Object.entries(data).forEach(([key]) => {
                porpsByname.forEach((datas) => {
                    if (key === datas) {
                        tempO[key] = data[key];
                    }
                });
            });
            temp.push(tempO);
        }
    });
    const res = h.response({
        status: 'success',
        data: { books: temp }
    });
    res.code(200);
    return res;
};

const GetBookByFinished = async (req, h) => {
    let finished = req;
    let temp = [];
    let tempO = {};
    let isF = finished == 0 ? false : true;
    await readData(stored);

    exist.forEach((data) => {
        if (data.finished === isF) {
            Object.entries(data).forEach(([key]) => {
                porpsByname.forEach((datas) => {
                    if (key === datas) {
                        tempO[key] = data[key];
                    }
                });
            });
            temp.push(tempO);
        }
    });
    const res = h.response({
        status: 'success',
        data: { books: temp }
    });
    res.code(200);
    return res;
};

module.exports = { GetBook, GetBookById };

const Hapi = require('@hapi/hapi');
const routers = require('./routes');

const init = async () => {
    const server = Hapi.server({
        port: 9000,
        host: 'localhost'
    });

    server.route(routers);

    await server.start();
    console.log(`server running at ${server.info.uri}`);
};

init();

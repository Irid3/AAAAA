const { GetBook, GetBookById } = require('./handler/GetBooks');
const PostHandler = require('./handler/PostBooks');
// const { GetBook, GetBookById } = require('./handler/GetBooks');
const { PutBookById, DeleteBookById } = require('./handler/AlterBooks');
// GetBookByName, GetBookReading, GetBookFinished;
const routes = [
    {
        method: 'GET',
        path: '/',
        handler: (req, h) => {
            const res = h.response({
                status: 'success',
                message: 'ini Home'
            });
            res.code(200);
            return res;
        }
    },
    {
        method: 'POST',
        path: '/books',
        handler: PostHandler
    },
    {
        method: 'GET',
        path: '/books',
        handler: GetBook
    },
    {
        method: 'GET',
        path: '/books/{bookid}',
        handler: GetBookById
    },
    {
        method: 'PUT',
        path: '/books/{bookid}',
        handler: PutBookById
    },
    {
        method: 'DELETE',
        path: '/books/{bookid}',
        handler: DeleteBookById
    }
];

module.exports = routes;
